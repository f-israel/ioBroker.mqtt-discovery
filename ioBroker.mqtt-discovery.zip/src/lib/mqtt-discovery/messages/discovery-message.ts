import type { DiscoveryMessagePayload } from "./discovery-message-payload";

export interface DiscoveryMessage {
    /**
     *
     */
    topic: string; // MQTT Discovery Topic, z.B. "homeassistant/sensor/my_device_config/config"
    payload: DiscoveryMessagePayload; // JSON-Payload, die die Konfiguration enthält
}
